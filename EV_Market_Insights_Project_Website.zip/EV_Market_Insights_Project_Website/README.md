# EV Market Insights — Project Website

A responsive static project showcase for the EV Vehicles Insights / EV Market Performance Insights project.

## Included
- `index.html` — page content and project links
- `style.css` — responsive layout and styling
- `script.js` — mobile navigation behavior

## Run locally on your Mac
1. Download and unzip the project folder.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in your browser, or use the VS Code Live Server extension.
4. You can also run a simple local server from Terminal inside this folder:
   ```bash
   python3 -m http.server 8000
   ```
5. Visit `http://localhost:8000`.

## Customize
- Replace the illustrative dashboard artwork with screenshots from your actual Tableau workbook.
- To embed a live Tableau view, publish the workbook to Tableau Public and replace the placeholder in `index.html` with the official embed code.
- The page currently links to the supplied GitHub repositories and files.
- To include the MP4 preview, copy `EV_Market_Project_Demo_Preview.mp4` into this folder. The resource link in the page will then work.

## Note
The dashboard visuals in the hero and cards are decorative mockups. This site does not claim to display live Tableau data or run the Flask application inside the page.
